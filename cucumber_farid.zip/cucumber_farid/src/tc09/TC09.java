package tc09;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class TC09 {
	public static WebDriver driver;
	@Given("^User is on Home Page$")
	public void user_is_on_Home_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Farid\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe"); 
		ChromeOptions options = new ChromeOptions();
		options.addArguments("start-maximized");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.navigate().to("https://agoda.com/");
		}

	@When("^User Searches for a hotel$")
	public void user_searches_for_a_hotel() throws Throwable {
		Actions actions = new Actions(driver);
		//Wait for Ad
		Thread.sleep(8000);
		//Close Ad
		actions.moveToElement(driver.findElement(By.className("ab-close-button"))).click().build().perform();
		//Search for a hotel in Tokyo
		driver.findElement(By.xpath("//*[@id=\"textInput\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"textInput\"]")).sendKeys("Enzo Tokyo");
		actions.moveToElement(driver.findElement(By.xpath("//*[@id=\"tab-all-rooms-tab\"]/div"))).click().build().perform();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Thread.sleep(1000);
		js.executeScript("window.scrollBy(0,10000)");
		Thread.sleep(3000);
		//Click on search
		actions.moveToElement(driver.findElement(By.xpath("//*[@id=\"SearchBoxContainer\"]/div[1]/div/div[2]/div/div/button"))).click().build().perform();
		//wait for search results
		Thread.sleep(3000);
		js.executeScript("window.scrollBy(0,3000)");
		//click Enzo Tokyo
		js.executeScript("window.scrollBy(0,300)");
		actions.moveToElement(driver.findElement(By.xpath("//*[@id=\"contentContainer\"]/div[3]/ol/li[1]/div[2]/a"))).click().build().perform();
		//switch to new tab
		ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs.get(tabs.size()-1));
		Thread.sleep(5000);
		js.executeScript("window.scrollBy(0,2000)");
		//add to cart
		actions.moveToElement(driver.findElement(By.cssSelector(".jxFsnW"))).click().build().perform();
		Thread.sleep(5000);
		actions.moveToElement(driver.findElement(By.cssSelector(".eZCQek"))).click().build().perform();
		Thread.sleep(3000);
		actions.moveToElement(driver.findElement(By.cssSelector(".blnWzF"))).click().build().perform();
		}

	@Then("^cart displays added room ucessfully$")
	public void cart_displays_added_room_successfully() throws Throwable {
		//check cart
		if(driver.findElement(By.cssSelector(".cEdVhr")).isDisplayed())
		{
			System.out.println("Item added to cart succesfully");
		}
		else 
		{
			System.out.println("Failed to add item to cart");
		}
	}

}
